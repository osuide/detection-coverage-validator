'use strict';

/**
 * A13E Lambda@Edge Security Headers Function
 * Adds comprehensive security headers to CloudFront responses
 */

exports.handler = async (event) => {
  const response = event.Records[0].cf.response;
  const headers = response.headers;

  // Build Content Security Policy
  // SECURITY NOTE: 'unsafe-inline' is required for:
  // - script-src: Stripe.js requires inline event handlers for PCI compliance
  // - style-src: Tailwind CSS and React inline styles
  // TODO: Migrate to nonce-based CSP when Stripe Elements supports it
  // See: https://stripe.com/docs/security/guide#content-security-policy
  const csp = [
    "default-src 'self'",
    "script-src 'self' 'unsafe-inline' https://js.stripe.com https://cdn.redocly.com",
    "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://cdn.jsdelivr.net",
    "img-src 'self' data: blob: https:",
    "connect-src 'self' https://api.staging.a13e.com https://api.stripe.com",
    "frame-src https://js.stripe.com",
    "font-src 'self' data: https://fonts.gstatic.com",
    "base-uri 'self'",
    "form-action 'self'",
    "frame-ancestors 'none'",
    "upgrade-insecure-requests"
  ].join('; ');

  // Remove revealing AWS headers
  delete headers['x-amz-server-side-encryption'];
  delete headers['x-amz-version-id'];
  delete headers['x-amz-id-2'];
  delete headers['x-amz-request-id'];
  delete headers['via'];

  // Set custom server header
  headers['server'] = [{ key: 'Server', value: 'a13e' }];

  // Security headers
  headers['content-security-policy'] = [{
    key: 'Content-Security-Policy',
    value: csp
  }];

  headers['strict-transport-security'] = [{
    key: 'Strict-Transport-Security',
    value: 'max-age=31536000; includeSubDomains; preload'
  }];

  headers['x-content-type-options'] = [{
    key: 'X-Content-Type-Options',
    value: 'nosniff'
  }];

  headers['x-frame-options'] = [{
    key: 'X-Frame-Options',
    value: 'DENY'
  }];

  headers['x-xss-protection'] = [{
    key: 'X-XSS-Protection',
    value: '1; mode=block'
  }];

  headers['referrer-policy'] = [{
    key: 'Referrer-Policy',
    value: 'strict-origin-when-cross-origin'
  }];

  headers['permissions-policy'] = [{
    key: 'Permissions-Policy',
    value: 'geolocation=(), camera=(), microphone=(), payment=(), usb=(), magnetometer=(), gyroscope=(), accelerometer=()'
  }];

  headers['cross-origin-opener-policy'] = [{
    key: 'Cross-Origin-Opener-Policy',
    value: 'same-origin'
  }];

  headers['cross-origin-embedder-policy'] = [{
    key: 'Cross-Origin-Embedder-Policy',
    value: 'credentialless'
  }];

  headers['cross-origin-resource-policy'] = [{
    key: 'Cross-Origin-Resource-Policy',
    value: 'same-site'
  }];

  return response;
};
