'use strict';

/**
 * A13E Lambda@Edge Security Headers Function
 * Adds comprehensive security headers to CloudFront responses
 */

exports.handler = async (event) => {
  const response = event.Records[0].cf.response;
  const headers = response.headers;

  // Build Content Security Policy - STRICT
  // All JavaScript is bundled via Vite - no external CDNs needed
  // Payment: Uses Stripe Checkout redirect (not embedded Stripe.js)
  // Fonts: System fonts only (Inter with system-ui fallbacks)
  // SECURITY NOTE: 'unsafe-inline' for style-src is required for:
  // - Tailwind CSS dynamically generated classes
  // - React inline styles
  const csp = [
    "default-src 'self'",
    "script-src 'self'",
    "style-src 'self' 'unsafe-inline'",
    "img-src 'self' data: blob:",
    "connect-src 'self' https://api.staging.a13e.com",
    "font-src 'self'",
    "frame-src 'none'",
    "object-src 'none'",
    "base-uri 'self'",
    "form-action 'self'",
    "frame-ancestors 'none'",
    "upgrade-insecure-requests"
  ].join('; ');

  // Remove revealing AWS headers
  delete headers['x-amz-server-side-encryption'];
  delete headers['x-amz-version-id'];
  delete headers['x-amz-id-2'];
  delete headers['x-amz-request-id'];
  delete headers['via'];

  // Set custom server header
  headers['server'] = [{ key: 'Server', value: 'a13e' }];

  // Security headers
  headers['content-security-policy'] = [{
    key: 'Content-Security-Policy',
    value: csp
  }];

  headers['strict-transport-security'] = [{
    key: 'Strict-Transport-Security',
    value: 'max-age=31536000; includeSubDomains; preload'
  }];

  headers['x-content-type-options'] = [{
    key: 'X-Content-Type-Options',
    value: 'nosniff'
  }];

  headers['x-frame-options'] = [{
    key: 'X-Frame-Options',
    value: 'DENY'
  }];

  headers['x-xss-protection'] = [{
    key: 'X-XSS-Protection',
    value: '1; mode=block'
  }];

  headers['referrer-policy'] = [{
    key: 'Referrer-Policy',
    value: 'strict-origin-when-cross-origin'
  }];

  headers['permissions-policy'] = [{
    key: 'Permissions-Policy',
    value: 'geolocation=(), camera=(), microphone=(), payment=(), usb=(), magnetometer=(), gyroscope=(), accelerometer=()'
  }];

  headers['cross-origin-opener-policy'] = [{
    key: 'Cross-Origin-Opener-Policy',
    value: 'same-origin'
  }];

  headers['cross-origin-embedder-policy'] = [{
    key: 'Cross-Origin-Embedder-Policy',
    value: 'credentialless'
  }];

  headers['cross-origin-resource-policy'] = [{
    key: 'Cross-Origin-Resource-Policy',
    value: 'same-site'
  }];

  // X-Robots-Tag: Block AI training crawlers while allowing search indexing
  // This supplements robots.txt with HTTP header enforcement
  headers['x-robots-tag'] = [
    { key: 'X-Robots-Tag', value: 'noai, noimageai' },
    { key: 'X-Robots-Tag', value: 'GPTBot: noindex, nofollow' },
    { key: 'X-Robots-Tag', value: 'ChatGPT-User: noindex, nofollow' },
    { key: 'X-Robots-Tag', value: 'Google-Extended: noindex, nofollow' },
    { key: 'X-Robots-Tag', value: 'CCBot: noindex, nofollow' },
    { key: 'X-Robots-Tag', value: 'anthropic-ai: noindex, nofollow' },
    { key: 'X-Robots-Tag', value: 'Bytespider: noindex, nofollow' },
    { key: 'X-Robots-Tag', value: 'PerplexityBot: noindex, nofollow' },
    { key: 'X-Robots-Tag', value: 'Amazonbot: noindex, nofollow' },
    { key: 'X-Robots-Tag', value: 'FacebookBot: noindex, nofollow' },
    { key: 'X-Robots-Tag', value: 'cohere-ai: noindex, nofollow' }
  ];

  return response;
};
